/* Картинки: png/kaplya-<id>.png. Позы меняют движение целой картинки. */
(function(global){
  const poses=['idle','walk','sleep','work','think','happy'];
  const ids=["idle", "sleep", "think", "detective", "chef", "work", "wallet", "music", "gamer", "cool", "reader", "idea", "winter", "ski", "rain", "explorer", "headphones", "cozy", "campfire", "coder", "engineer", "scientist", "astronaut", "ufo", "samurai", "wizard", "king", "gentleman", "ninja", "knight", "viking", "pirate", "santa", "reindeer", "ghost", "pumpkin", "angel", "devil", "bat", "vampire", "sprout", "leaf", "flowers", "summer", "skater", "cat", "photographer", "bath"];
  class KaplyaPet {
    constructor(container,{character='idle',pose='idle',basePath=''}={}) {
      if(!container || typeof container.appendChild!=='function')throw new TypeError('Нужен DOM-контейнер');
      this.container=container;this.basePath=basePath.replace(/\/$/,'');
      this.image=document.createElement('img');this.image.className='pet';
      this.image.width=512;this.image.height=512;this.image.draggable=false;
      container.replaceChildren(this.image);this.setCharacter(character);this.setPose(pose);
    }
    setCharacter(id){if(!ids.includes(id))throw new RangeError('Неизвестный персонаж: '+id);this.character=id;this.image.src=(this.basePath?this.basePath+'/':'')+'png/kaplya-'+id+'.png';this.image.alt=id;return this;}
    setPose(pose){if(!poses.includes(pose))throw new RangeError('Неизвестная поза: '+pose);this.container.dataset.pose=pose;return this;}
    destroy(){this.image.remove();delete this.container.dataset.pose;}
  }
  global.KaplyaPet=KaplyaPet;
})(globalThis);
